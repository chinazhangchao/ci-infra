"""Build metadata for flashinfer package."""
__version__ = "0.6.17"
__git_commit__ = "9b5b6a8790e33b19a7bf3d67ce0c20866dd576a7"
