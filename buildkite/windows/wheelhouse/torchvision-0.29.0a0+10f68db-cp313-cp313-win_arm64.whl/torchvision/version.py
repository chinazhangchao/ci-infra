__version__ = '0.29.0a0+10f68db'
git_version = '10f68dbd78b9aa5cab9328f3b2e99cfb0b608122'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
